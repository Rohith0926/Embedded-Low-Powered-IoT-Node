#include "stm32f4xx.h"

void UART_Init(void)
{
}
void BLE_Send(char *msg)
{
    while(*msg)
    {
        while(!(USART2->SR & (1<<7)));
        USART2->DR=*msg++;
    }
}