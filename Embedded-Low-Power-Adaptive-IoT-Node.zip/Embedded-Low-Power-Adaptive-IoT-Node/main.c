#include "stm32f4xx.h"

void UART_Init(void);
void ADC_Init(void);
void BLE_Send(char *msg);
int Read_Temperature(void);
int Read_Light(void);
int Read_Vibration(void);
void Delay(void);

int main(void)
{
    int temp,light,vibration;
    UART_Init();
    ADC_Init();
    while(1)
    {
        temp=Read_Temperature();
        light=Read_Light();
        vibration=Read_Vibration();
        BLE_Send("Temperature Data\n");
        BLE_Send("Light Data\n");
        BLE_Send("Vibration Data\n");
        if(vibration==1)
        {
            BLE_Send("Vibration Detected\n");
        }
        Delay();
        __WFI(); // Sleep mode
    }
}

void Delay(void)
{
    int i,j;
    for(i=0;i<300;i++)
        for(j=0;j<3000;j++);
}
