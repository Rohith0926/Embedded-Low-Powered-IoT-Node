#include "stm32f4xx.h"

int Read_Temperature(void)
{
    return 30;
}
int Read_Light(void)
{
    return 450;
}
int Read_Vibration(void)
{
    return 0;
}