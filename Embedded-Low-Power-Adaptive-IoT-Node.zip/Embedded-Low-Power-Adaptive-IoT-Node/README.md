# Embedded Low-Power Adaptive IoT Node

STM32 Embedded C project for environmental monitoring.

## Components
- STM32
- LM35 Temperature Sensor
- LDR
- SW-420 Vibration Sensor
- HM-10 BLE Module

## Features
- Reads multiple sensors
- Sends data through BLE
- UART communication
- Basic low-power sleep mode
- Simple polling-based implementation